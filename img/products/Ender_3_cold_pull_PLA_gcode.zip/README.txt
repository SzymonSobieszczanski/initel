                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3245546
Ender 3 cold pull PLA gcode by sako83 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is the gcode I use for the cold pull routine on the Ender 3, I use this every time I change filament. This is for PLA.

Credit goes to 3dviking, this is a modified version of his code found here.
https://3dviking.wordpress.com/2017/09/30/cold-pulls-for-the-easily-distracted/

This is what the gcode executes:
- heat nozzle to 255
- cool down to 190
- extrude 10mm
- home all axis and move extruder to the right for easier filament removal
- cool down to 90
- play a sound to alert

When the sound plays, you should yank the filament and then pull it out.

Other temperatures for cold pull of different materials are noted inside the gcode. Again thanks to 3dviking for this.

IGNORE THE STL FILE just download cold_pull_pla.gcode and put it on your sd card.